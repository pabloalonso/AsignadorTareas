package com.bonitasoft.bbva.rest;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.sql.DataSource;

import org.apache.http.HttpHeaders
import org.bonitasoft.engine.api.ProcessAPI;
import org.bonitasoft.engine.expression.Expression;
import org.bonitasoft.engine.expression.ExpressionBuilder;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController
import com.company.model.ProcessSearchIndexes;
import com.company.model.ProcessSearchIndexesDAO;
import com.fasterxml.jackson.databind.ObjectMapper;


class GestorPrioridad implements RestApiController {

    private static final Logger LOGGER = LoggerFactory.getLogger(GestorPrioridad.class)

    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {

		try{
			def jsonBuilder = new JsonBuilder(new JsonSlurper().parseText(getBody(request)))
			Properties props = loadProperties("configuration.properties", context.resourceProvider)
			String targetEvent = props["targetEvent"]
			String targetPool = props["targetPool"]
			String msgName = props["msgName"]
			
			LOGGER.warn("json")
			LOGGER.warn(jsonBuilder.toPrettyString());
			def json = jsonBuilder.getContent()
	        
			ProcessAPI pAPI = context.getApiClient().getProcessAPI();
			
			Expression targetProcess = new ExpressionBuilder().createConstantStringExpression(targetPool);
			Expression targetFlowNode = new ExpressionBuilder().createConstantStringExpression(targetEvent);
			
			Map<Expression,Expression> messageContent = new HashMap<Expression,Expression>();
			Expression varName = new ExpressionBuilder().createConstantStringExpression("statusPrioridad");
			Expression varValue = new ExpressionBuilder().createConstantStringExpression("statusPrioridadExp", json.statusPrioridad?json.statusPrioridad:"");			
			
			messageContent.put(varName, varValue);
			
			varName = new ExpressionBuilder().createConstantStringExpression("caseId");
			varValue = new ExpressionBuilder().createConstantLongExpression(json.id_caso);
			messageContent.put(varName, varValue);
			
			varName = new ExpressionBuilder().createConstantStringExpression("userId");			
			varValue = new ExpressionBuilder().createConstantLongExpression(context.apiSession.getUserId());
			messageContent.put(varName, varValue);			
			
			pAPI.sendMessage(msgName, targetProcess, targetFlowNode, messageContent)
			return buildResponse(responseBuilder, HttpServletResponse.SC_OK,"""{"status" :"Prioridad cambiada" }""")
		} catch(Exception e){
			LOGGER.error(e.getMessage());
			return buildResponse(responseBuilder, HttpServletResponse.SC_SERVICE_UNAVAILABLE,"""{"error" :" Ha ocurrido un error desconocido, pongase en contacto con el administrador "}""")
		}
    }
	
	private Connection getConnection(String dsName){
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup(dsName);
		Connection conn = ds.getConnection();
		return conn;
	}

    /**
     * Build an HTTP response.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  httpStatus the status of the response
     * @param  body the response body
     * @return a RestAPIResponse
     */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
     * Returns a paged result like Bonita BPM REST APIs.
     * Build a response with content-range data in the HTTP header.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  body the response body
     * @param  p the page index
     * @param  c the number of result per page
     * @param  total the total number of results
     * @return a RestAPIResponse
     */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }

    /**
     * Load a property file into a java.util.Properties
     */
    Properties loadProperties(String fileName, ResourceProvider resourceProvider) {
        Properties props = new Properties()
        resourceProvider.getResourceAsStream(fileName).withStream { InputStream s ->
            props.load s
        }
        props
    }
	public String getBody(HttpServletRequest request) throws IOException {
		
			String body = null;
			StringBuilder stringBuilder = new StringBuilder();
			BufferedReader bufferedReader = null;
		
			try {
				InputStream inputStream = request.getInputStream();
				if (inputStream != null) {
					bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
					char[] charBuffer = new char[128];
					int bytesRead = -1;
					while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
						stringBuilder.append(charBuffer, 0, bytesRead);
					}
				} else {
					stringBuilder.append("");
				}
			} catch (IOException ex) {
				throw ex;
			} finally {
				if (bufferedReader != null) {
					try {
						bufferedReader.close();
					} catch (IOException ex) {
						throw ex;
					}
				}
			}
		
			body = stringBuilder.toString();
			return body;
		}
	
	public String parseProcessSearchIndexes(List<ProcessSearchIndexes> psis, Long idCaso){
		Map<String, Map<String, String>> output = new HashMap<String, Map<String, String>>();
		Map<String, String> map;
		if(psis.size() == 0){
			return  "No hay ninguna caso con dicho ID";
		}else{
			for(ProcessSearchIndexes psi : psis){	
				
				map = output.get(psi.getId_caso());
				if(map == null){
					map = new HashMap<String, String>();
					map.put("id_caso", psi.getId_caso());
					map.put("id_proceso", psi.getId_proceso());
				}
				map.put(psi.getClave(),psi.getValor());
				output.put(psi.getId_caso(), map);			
			}
			/*
			if(idCaso != null){
				return  new ObjectMapper().writeValueAsString(output.get(idCaso));
			}else{		
				return  new ObjectMapper().writeValueAsString(output.values());
			}
			*/
			return  new ObjectMapper().writeValueAsString(output.values());
		}
		
	}

}
