(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customCustomWidgetSideMenuLayout', function() {
    return {
      controllerAs: 'ctrl',
      controller: function WidgetlivingApplicationMenuController($scope, $http, $window, $element, $interval, $sce) {
    var ctrl = this;
    var pathArray = $window.location.pathname.split( '/' );
    ctrl.applicationToken =  pathArray[pathArray.length-3]; 
    ctrl.pageToken =  pathArray[pathArray.length-2];
    
    function getApplication() {
        return $http.get('../API/living/application/?c=1&f=token%3D'+ctrl.applicationToken);
    }
    
    this.filterChildren = function (parentId) {
        return (ctrl.applicationMenuList||[]).filter(function(menu){
            return menu.parentMenuId === '' + parentId;
        });
        
    }
   
    function getApplicationMenuList(applicationId) {
        
        $http.get('../API/living/application-menu/?c=100&f=applicationId%3D'+applicationId+'&d=applicationPageId&o=menuIndex+ASC')
            .success(function(data) { 
                ctrl.applicationMenuList = data;
            });
        return applicationId;
    }

    function setTargetedUrl() {
        $scope.properties.targetUrl = "../../../portal/resource/app/"+ctrl.applicationToken+"/"+ ctrl.pageToken+"/content/"+ $window.location.search + ctrl.searchSeparator() + "app=" + ctrl.applicationToken;
    }

    ctrl.searchSeparator = function() {
        return $window.location.search ? "&" : "?";
    };

    ctrl.isParentMenu= function(menu) {
        return menu.parentMenuId==-1 && menu.applicationPageId==-1;
    };
    
    getApplication().then(function(response) {
        var application = response.data[0];
        ctrl.applicationName = application.displayName;
        $window.document.title = application.displayName;
        return application.id;
    }).then(getApplicationMenuList).then(setTargetedUrl);
    
    if ($scope.properties.resizeToContent) {
    
        var iframe = $element.find('iframe')[0];
    
        var polling = $interval(function() {
            if(iframe.contentDocument.documentElement){
    			iframe.style.height = (iframe.contentDocument.documentElement.scrollHeight || 600) + "px";
    		}
        }, 100);
        
        $scope.$on('$destroy', function() {
            $interval.cancel(polling);
        });
            
    }
    
    $scope.secureUrl = function() {
        return $sce.trustAsResourceUrl($scope.properties.targetUrl);
    };
    
},
      template: '<div id="wrapper" class="toggled col-xs-12  col-sm-12  col-md-12  col-lg-12" >\n    <div id="sidebar-wrapper">\n        <ul class="sidebar-nav">\n            <li class="sidebar-brand">\n                <!--<a href="..">{{ctrl.applicationName}}</a>-->\n                <a href="..">\n                    <img id="logo" class="img-responsive ng-scope" alt="{{ctrl.applicationName}}" src="widgets/customCustomWidgetSideMenuLayout/assets/img/logoBBVA.PNG">\n                </a>\n            </li>\n            <li ng-class="{active:ctrl.pageToken===menu.applicationPageId.token}" ng-repeat="menu in ctrl.filterChildren(-1)" dropdown>\n                <a ng-if="!ctrl.isParentMenu(menu)" ng-href="../{{menu.applicationPageId.token}}/" >{{menu.displayName}}</a>\n                <a ng-if="ctrl.isParentMenu(menu)" dropdown-toggle>{{menu.displayName}}<span class="caret"></span></a>\n                <ul ng-if="ctrl.isParentMenu(menu)" class="dropdown-menu">\n                    <li ng-repeat="childMenu in ctrl.filterChildren(menu.id)">\n                        <a ng-href="../{{childMenu.applicationPageId.token}}/">{{childMenu.displayName}}</a>\n                    </li>\n                </ul>\n            </li>\n        </ul>\n    </div>\n    <iframe ng-src="{{secureUrl()}}" class="col-xs-12  col-sm-12  col-md-12  col-lg-12"></iframe>\n</div>'
    };
  });
