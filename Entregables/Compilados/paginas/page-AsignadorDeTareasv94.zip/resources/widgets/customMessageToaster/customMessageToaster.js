(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customMessageToaster', function() {
    return {
      controllerAs: 'ctrl',
      controller: // Wrap of the module developed here http://ngmodules.org/modules/AngularJS-Toaster
function ($scope, toaster) {
    $scope.$watchCollection('properties.toasters', function (data) {
        if (!Array.isArray(data)) {
            return;
        }
        
        if(data.length > 0) {
            var toast = data.shift();
            console.log(toast);
            toaster.pop(
                (toast.type ? toast.type : "none"), 
                (toast.title ? toast.title : "Default title"), 
                (toast.text ? toast.text : "Default text"), 
                (toast.timeout ? toast.timeout : undefined), 
                toast.textType
            );
        }
    });
},
      template: '<toaster-container toaster-options="{{properties.options}}"></toaster-container>'
    };
  });
