(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customProgressBar', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbChartCtrl($scope, $log, uiTranslateFilter) {

//init de la primera barra
  $scope.label = "Tareas Pendientes : ";
  $scope.className = "progress-bar-striped";
//

  function isMultiSeriesChart(chartType) {
    return ["Line", "Bar", "Radar"].indexOf(chartType) > -1;
  }

  function isFlatArray(array) {
    return array && array[0] && !Array.isArray(array[0]);
  }

  function translateArray(array) {
    return (array || []).map(function(item) {
      return uiTranslateFilter(item);
    })
  }
  
  $scope.$watch('properties.data', function(value) {
    if (isMultiSeriesChart($scope.properties.type) && isFlatArray($scope.properties.data)) {
      $scope.data = [$scope.properties.data];
    } else {
      $scope.data = $scope.properties.data;
    }
    
    var total = $scope.data[0] + $scope.data[1];
    if(total > 0){
        var fW = ($scope.data[0]/total)*100;
        var sW = ($scope.data[1]/total)*100;
        
        if(fW < 20 && $scope.data[0] > 0){
            fW = "20%";
            sW = "80%";
        }else if (sW <20 && $scope.data[1] > 0){
            sW = "20%";
            fW = "80%";
        }else{
            fW = fW + "%";
            sW = sW + "%";
        }
        
        $scope.firstWidth = fW;
        $scope.secondWidth = sW;
    }else{
        $scope.hideB = true;
        $scope.data[0] = "";
        $scope.label = "No hay tareas pendientes";
        $scope.firstWidth = 100 + "%";
        $scope.className = "progress-bar-danger";
    }

  });

  $scope.$watch('properties.colors', function(value) {
    $scope.colors = ($scope.properties.colors || []).length > 0 ? $scope.properties.colors : null;
  });

  $scope.$watch('properties.options', function(value) {
    if (angular.isString(value)) {
      try {
        $scope.options = angular.fromJson(value);
      } catch (e) {
        $log.error('[Chart widget] Advanced options property should be a valid json object, ex: { "animateRotate" : false }');
      }
    } else {
      $scope.options = value;
      
    }
  });

  $scope.$watch('properties.labels', function(labels) {
    if(angular.isArray(labels)) {
      $scope.labels = translateArray(labels);
    } else {
      $log.error('[Chart widget] Property named "labels" should be bound to an array');
    }
  });

  $scope.$watch('properties.setLabels', function(setLabels) {
    if(angular.isArray(setLabels)) {
      $scope.setLabels = translateArray(setLabels);
    } else {
      $log.error('[Chart widget] Property named "setLabels" should be bound to an array');
    }
  });
}
,
      template: '<div>\n<h1> </h1>\n  <div class="progress" style="height: 20px">\n    <div \n        class="progress-bar active"\n        ng-class="className"\n        ng-style="{\'width\':firstWidth}">\n		<b>{{label}}{{data[0]}}</b>\n	</div>\n    <div \n        ng-hide="hideB"\n        class="progress-bar progress-bar-success progress-bar-striped active"  \n        ng-style="{\'width\':secondWidth}">\n        <b> Tareas Realizadas : {{data[1]}} </b>\n    </div>\n  </div>\n</div>\n'
    };
  });
