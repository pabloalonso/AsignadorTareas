(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customFormIframe', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope, $window) { 
    
    window.resizeIframe=function(iframeID, divID){
        
        var container = document.getElementById(divID);
        var ifrm = document.getElementById(iframeID);
        
        var doc = ifrm.contentDocument? ifrm.contentDocument: 
        ifrm.contentWindow.document;
        //ifrm.style.visibility = 'hidden';
        ifrm.style.height = "10px";
        
        doc = doc || document;
        var body = doc.body, html = doc.documentElement;
        var height = Math.max( body.scrollHeight, body.offsetHeight, 
        html.clientHeight, html.scrollHeight, html.offsetHeight );
        
        ifrm.style.height = height + 7 + "px";
        //ifrm.style.visibility = 'visible';
        
        container.style.height = ifrm.style.height;
        
        
        //"aiFrame" y "divFrame" son los ids de los elementos del iframe y el div que lo contiene respectivamente
       // doc.addEventListener('click', function(event) {            resizeIframe('aiFrame','divFrame');        });
    }
  
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n<div id="divFrame" class="embed-responsive embed-responsive-16by9">\n    <iframe id="aiFrame" src="{{ properties.value }}" scrolling="yes" frameborder="0" onLoad="resizeIframe(\'aiFrame\',\'divFrame\');"></iframe>\n    <!--<iframe class="embed-responsive-item" src="{{ properties.value }}" ></iframe>-->\n</div>\n\n'
    };
  });
