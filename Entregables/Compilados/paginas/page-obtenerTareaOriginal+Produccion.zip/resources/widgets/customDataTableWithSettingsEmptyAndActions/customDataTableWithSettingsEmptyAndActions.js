(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customDataTableWithSettingsEmptyAndActions', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomDataTableWithSettingsEmptyAndActionsCtrl($scope, $http, $log, $filter, $injector, $interpolate) {

  var vm = this;
  
  this.pageSize = $scope.properties.defaultPageSize ? $scope.properties.pageSizes.find(function(item) { return item + "" === "" + $scope.properties.defaultPageSize }) : $scope.properties.pageSizes[0];
  
  this.loading = true;
  
  Object.defineProperty(vm, 'jsonData', {
    'get': function () {
      //undefined for filter expression allows to bypass the null value issue that
      //filters everything
      var data = $filter('filter')(this.data || [], $scope.properties.filter || undefined);
      return $filter('orderBy')(data, vm.sortOptions.property, vm.sortOptions.direction);
    },
    'set': function (data) {
      this.data = data;
    }
  });

  this.sortOptions = {
    property: ($scope.properties.defaultSortColumn ? $scope.properties.defaultSortColumn : ($scope.properties.sortColumns || [])[0]),
    direction: ($scope.properties.defaultSortOrder ? $scope.properties.defaultSortOrder === 'DESC' : false)
  };
  
  this.pagination = {
    currentPage: 1,
    total: 0
  };
  
  this.columns = $scope.properties.headers.map(function(header) {
      return {
        name: $interpolate('{{ header | uiTranslate }}')({ header: header }),
        visible: true
      };
  });

  /**
   * helper methods
   */
  this.hasMultiColumns = function () {
    return Array.isArray($scope.properties.columnsKey);
  };

  this.isSelectable = function () {
    return $scope.properties.isBound('selectedRow');
  };

  this.hasActions = function () {
    return $scope.properties.isBound('actions');
  };

  /**
   * Create a request object following $http(request)
   * @return {Object} a request Object
   */
  this.createRequest = function () {
    var params = {
      c: this.pageSize,
      p: this.pagination.currentPage - 1 || 0,
      s: $scope.properties.filter
    };

    if (this.sortOptions.property) {
      params.o = this.sortOptions.property + ' ' + (this.sortOptions.direction ? 'DESC' : 'ASC');
    }
    return {
      url: this.removeHandledParams($scope.properties.apiUrl),
      transformResponse: $http.defaults.transformResponse.concat(transformResponse),
      params: angular.extend({}, $scope.properties.params || {}, params)
    };
  };

  this.removeHandledParams = function(url) {
    return ['c', 'p'].reduce(
      function(acc, param) {
        //we cannot use pbDataTable because the widget build (probably mustache) replace it
        // with the widget name...
        return acc.replace(new RegExp('(&' + param + '=[^&#]*([&#])?)', 'g'), '$2').replace(new RegExp('[?]' + param + '=[^&#]*&?', 'g'), '?');
      },
      url || '');
  };

  this.refreshAPIURL = function () {
    $scope.properties.refreshTimestamp = new Date();
    $scope.properties.selectedRow = undefined;
  }

  /**
   *  Fire request and update results and pagination
   */
  this.updateResultsFromAPI = function () {
    if($scope.properties.apiUrl) {
      $http(vm.createRequest())
        .then(function (response) {
          vm.results = response.data.results;
          vm.pagination = response.data.pagination;
          vm.updateIsEmpty();
          vm.loading = false;
        })
        .catch(function (error) {
          vm.updateIsEmpty();
          vm.loading = false;
          $log.error(error);
        });
    }
  };
  
  this.updateIsEmpty = function() {
    if(Array.isArray(vm.results) && vm.results.length > 0) {
        $scope.properties.isEmpty = false;
    } else {
        $scope.properties.isEmpty = true;
    }
  };

  this.updateResultsFromJson = function () {
    var start = (vm.pagination.currentPage - 1) * vm.pageSize;
    var end = vm.pagination.currentPage * vm.pageSize;
    vm.results = vm.jsonData.slice(start, end);
    vm.updateIsEmpty();
    vm.loading = false;
  };


  this.sortHandler = function () {
    this.updateResults();
  };

  this.paginationHandler = function () {
    this.updateResults();
  };

  this.selectRowHandler = function (row) {
    if (this.isSelectable()) {
      $scope.properties.selectedRow = row;
    }
  };

  this.isColumnSortable = function(index) {
    return $scope.properties.type === 'Variable' ||
      (angular.isArray($scope.properties.sortColumns) &&
        $scope.properties.sortColumns.indexOf($scope.properties.columnsKey[index]) > -1);
  };

  function transformResponse(data, header) {
    return {
      results: data,
      pagination: parseContentRange(header('Content-Range'))
    };
  }

  /**
   * helper method which extract pagination data from Content-range HTTP header
   * @param  {String} strContentRange Content-Range value
   * @return {Object}                 object containing pagination
   */
  function parseContentRange(strContentRange) {
    if (strContentRange === null) {
      return {};
    }
    var arrayContentRange = strContentRange.split('/');
    var arrayIndexNumPerPage = arrayContentRange[0].split('-');
    return {
      total: parseInt(arrayContentRange[1], 10),
      currentPage: parseInt(arrayIndexNumPerPage[0], 10) + 1
    };
  }

  vm.updateResults = function () {
    vm.loading = true;
      
    if ($scope.properties.type === 'Variable') {
      vm.updateResultsFromJson();
    } else {
      vm.updateResultsFromAPI();
    }
  };

  //watchGroup does not support object equality so we use another way to monitor all at once
  $scope.$watch('[properties.refreshTimestamp, ctrl.pageSize, properties.apiUrl, properties.filter, properties.params]', resetPaginationAndUpdateResults, true);

  function resetPaginationAndUpdateResults() {
    vm.pagination = {
      currentPage: 1,
      total: vm.jsonData.length
    };
    vm.updateResults();
  }

  $scope.$watchCollection('properties.content', function (data) {
    if (!Array.isArray(data)) {
      return;
    }
    vm.jsonData = data;
    vm.pagination = {
      currentPage: 1,
      total: data.length
    };
    vm.updateResults();
  });
  
  this.isVisible = function(index) {
    return angular.isArray(vm.columns) && vm.columns[index].visible;
  };
}
,
      template: '<div class="table-responsive">\n    <table bonitable\n           sort-options="ctrl.sortOptions"\n           on-sort="ctrl.sortHandler()"\n           class="table table-striped" ng-class="{\'table-hover\': ctrl.isSelectable()}">\n        <thead>\n            <tr>\n                <th colspan="{{ properties.headers.length + 1 }}">\n                    <div class="bo-TableSettings pull-right" dropdown>\n                          <button type="button"\n                            ng-disabled="ctrl.loading"\n                            ng-if="properties.type === \'Bonita API\'"\n                            ng-click="ctrl.refreshAPIURL()"\n                            class="btn btn-primary">\n                            <span ng-show="ctrl.loading">\n                                <i class="glyphicon glyphicon-refresh spinning"></i>\n                            </span>\n                            <span ng-show="!ctrl.loading">\n                                <i class="glyphicon glyphicon-refresh"></i>\n                            </span>\n                          </button>\n                          <select\n                                class="dropdown-toggle btn btn-primary "\n                                ng-model="ctrl.pageSize"\n                                ng-disabled="ctrl.loading"\n                                ng-options="option as option for option in properties.pageSizes">\n                          </select>\n                          <button dropdown-toggle type="button"\n                            class="btn btn-primary bo-Settings dropdown-toggle navbar"\n                            ng-disabled="ctrl.results.length === 0"\n                            aria-labelledby="aria-tablesettings">\n                            <i class="glyphicon glyphicon-cog"></i>\n                          </button>\n                          <div class="bo-TableSettings-content dropdown-menu pull-right" role="menu" aria-labelledby="aria-tablesettings">\n                            <ul class="bo-TableSettings-columns bo-Text-disableSelection" as-sortable="sortableOptions" ng-model="ctrl.columns">\n                              <li  ng-repeat="field in ctrl.columns" as-sortable-item>\n                                  <div as-sortable-item-handle ng>\n                                      <label\n                                        class="bo-TableSettings-column"\n                                        title="{{((field.visible ? \'Hide\' : \'Show\') +\' \'+ field[\'name\']) | translate}}"\n                                        ng-click="$event.stopPropagation()">\n                                        <span class="glyphicon glyphicon-align-justify grabHover"></span>\n                                        <span class="glyphicon glyphicon-align-justify grabHover"></span>\n                                        <input type="checkbox" ng-model="field[\'visible\']" ng-change="ctrl.updateVisibility({field:field})">\n                                        {{::field[\'name\']}}\n                                      </label>\n                                  </div>\n                              </li>\n                            </ul>\n                          </div>\n                    </div>\n                </th>\n            </tr>\n            <tr>\n                <th ng-repeat="header in properties.headers" ng-if="ctrl.isVisible($index)">\n                    <div ng-if="ctrl.isColumnSortable($index)" bo-sorter="{{properties.columnsKey[$index]}}">\n                            {{ header | uiTranslate }}\n                    </div>\n                    <div ng-if="!ctrl.isColumnSortable($index)">\n                        {{ header | uiTranslate }}\n                    </div>\n                </th>\n                <th ng-if="ctrl.hasActions()" data-noresize="" class="table-column-xs table-header-actions ng-binding">Actions</th>\n            </tr>\n        </thead>\n        <tbody ng-if="ctrl.hasMultiColumns()">\n        <tr ng-repeat="row in ctrl.results" ng-click="ctrl.selectRowHandler(row)"\n            ng-class="{\'info\': (row === properties.selectedRow || (properties.highlightedRows && properties.highlightedRowsProperty && properties.highlightedRows.includes(row[properties.highlightedRowsProperty])))}">\n            <td ng-repeat="column in properties.columnsKey track by $index" ng-if="ctrl.isVisible($index)">\n                {{ $eval(column, row) | uiTranslate }}\n            </td>\n            <td ng-if="ctrl.hasActions()" class="application-actions">\n                <a ng-repeat="action in properties.actions track by $index"\n                    ng-if="!action.disabled(row)"\n                    href="{{action.href(row)}}" \n                    target="{{action.target(row)}}" \n                    style="text-decoration:none">\n                    <button\n                        class="{{action.glyphicon}} btn-action-{{action.name}}"\n                        aria-label="{{action.name}}"\n                        title="{{action.name}}"\n                        ng-click="action.handler(row)">{{action.tag}}\n                    </button>\n                </a>\n            </td>\n        </tr>\n        </tbody>\n        <tbody ng-if="!ctrl.hasMultiColumns()">\n        <tr ng-repeat="row in ctrl.results" ng-click="ctrl.selectRowHandler(row)"\n            ng-class="{\'info\': row === properties.selectedRow}">\n            <td> {{ row | uiTranslate }}</td>\n            <td ng-if="ctrl.hasActions()" class="application-actions">\n                <button ng-repeat="action in properties.actions track by $index"\n                        class="{{action.glyphicon}} btn-action-{{action.name}}"\n                        aria-label="{{action.name}}"\n                        title="{{action.name}}"\n                        ng-click="action.handler(row)">{{action.tag}}\n                </button>\n            </td>\n        </tr>\n        </tbody>\n    </table>\n    <pagination ng-if="ctrl.pagination.total > ctrl.pageSize" total-items="ctrl.pagination.total" items-per-page="ctrl.pageSize" direction-links="false" boundary-links="false"\n                ng-model="ctrl.pagination.currentPage" ng-change="ctrl.paginationHandler()"></pagination>\n</div>\n'
    };
  });
