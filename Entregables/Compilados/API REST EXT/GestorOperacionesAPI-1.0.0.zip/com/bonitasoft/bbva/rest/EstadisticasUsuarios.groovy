package com.bonitasoft.bbva.rest;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.sql.DataSource;

import org.apache.http.HttpHeaders
import org.bonitasoft.engine.identity.GroupSearchDescriptor;
import org.bonitasoft.engine.search.SearchOptionsBuilder;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.bonitasoft.engine.api.IdentityAPI;
import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

import com.fasterxml.jackson.databind.ObjectMapper;


class EstadisticasUsuarios implements RestApiController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EstadisticasUsuarios.class)

    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {		
		Properties props = loadProperties("configuration.properties", context.resourceProvider)
		String grupoBase = props["grupoBase"]
		
		
		IdentityAPI iAPI = context.getApiClient().getIdentityAPI();
		//Long grupoBaseId = iAPI.getGroupByPath(grupoBase).getId();
		SearchOptionsBuilder sob = new SearchOptionsBuilder(0, Integer.MAX_VALUE);
		sob.filter(GroupSearchDescriptor.PARENT_PATH,grupoBase);		
		def results = iAPI.searchGroups(sob.done()).getResult();
		
		
		//def results = iAPI.getUserMembershipsByGroup(grupoBaseId, 0, Integer.MAX_VALUE);		
		LOGGER.error("Estoy en un bloque de codigo que no se deberia ejecutar");
		return buildResponse(responseBuilder, HttpServletResponse.SC_ACCEPTED,new JsonBuilder(results).toPrettyString())
    }
	

    /**
     * Build an HTTP response.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  httpStatus the status of the response
     * @param  body the response body
     * @return a RestAPIResponse
     */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
     * Returns a paged result like Bonita BPM REST APIs.
     * Build a response with content-range data in the HTTP header.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  body the response body
     * @param  p the page index
     * @param  c the number of result per page
     * @param  total the total number of results
     * @return a RestAPIResponse
     */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }

    /**
     * Load a property file into a java.util.Properties
     */
    Properties loadProperties(String fileName, ResourceProvider resourceProvider) {
        Properties props = new Properties()
        resourceProvider.getResourceAsStream(fileName).withStream { InputStream s ->
            props.load s
        }
        props
    }
	

}
