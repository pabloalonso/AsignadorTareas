package com.bonitasoft.bbva.rest;

import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import groovy.json.JsonBuilder
import groovy.json.JsonSlurper;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.sql.DataSource;

import org.apache.http.HttpHeaders
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController
import com.company.model.ProcessSearchIndexes;
import com.company.model.ProcessSearchIndexesDAO;
import com.fasterxml.jackson.databind.ObjectMapper;


class GestorBusqueda implements RestApiController {

    private static final Logger LOGGER = LoggerFactory.getLogger(GestorBusqueda.class)

    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {

		Properties props = loadProperties("configuration.properties", context.resourceProvider)
		String serviceEndpoint = props["serviceEndpoint"]
		String datasource = props["datasource"]
		String searchIndexTable = props["searchIndexTable"]
		
		def jsonBuilder = new JsonBuilder(new JsonSlurper().parseText(getBody(request)))

		def json = jsonBuilder.getContent()
        
		/*
		 * FIltros por:
		 * ID CASO
		 * Cliente
		 * Cedula
		 * Monto Minimo
		 * Monto Maximo
		 */

		if(json.idCaso){
			String idCaso = json.idCaso ;
			try{
				Long idCasoLong = new Long (idCaso);			
				ProcessSearchIndexesDAO dao = context.getApiClient().getDAO(ProcessSearchIndexesDAO.class);
				List<ProcessSearchIndexes> caseIndexes = dao.findById_caso(idCasoLong,0,Integer.MAX_VALUE)
				String output = parseProcessSearchIndexes(caseIndexes, idCasoLong);
				return buildResponse(responseBuilder, HttpServletResponse.SC_OK, output )
			}catch (NumberFormatException  nfe){		
				LOGGER.error(nfe.getMessage());
				return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "El parametro idCaso tiene que ser numerico"}""")
			}catch (Exception e) {
				LOGGER.error(e.getMessage());
				return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "No se pudo buscar el caso con id """ + idCaso +""" "}""")
			}
		}else{
			try{
				String sql = "SELECT p.* FROM PROCESSSEARCHINDEXES p JOIN (SELECT id_caso, count(1) as num FROM PROCESSSEARCHINDEXES ";
				List<String> subSql = [];
				boolean isThereAnyFilter = false;
				if(json.cliente){				
					subSql.add("(CLAVE ='Cliente' and to_char(VALOR) like '%"+ json.cliente +"%' )")
					isThereAnyFilter=true;
				}
				if(json.cedula){
					subSql.add("(CLAVE ='Cedula' and to_char(VALOR) = '"+ json.cedula +"' )")
					isThereAnyFilter=true;
				}
				if(json.montoMin || json.montoMax){
					String ssql ="(CLAVE ='Monto' and (1=1";
					if(json.montoMin)
						ssql +=" and to_char(VALOR) >= "+json.montoMin 
					if(json.montoMax)
						ssql +=" and to_char(VALOR) <= " + json.montoMax
						
					subSql.add(ssql+") )")
					isThereAnyFilter=true;
				}
				if(	!isThereAnyFilter){
					return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "No hay ningun filtro definido"}""")
				}else{
					sql += " WHERE "
				}
				for(int i =0; i< subSql.size(); i++){
					String ssql = subSql.get(i);
					if(subSql.size() > (i+1))
						ssql += " OR "
					sql += ssql;	
				}
				sql +=" group by id_caso having count(1) = "+ subSql.size() +") p2 ON (p.id_caso =  p2.id_caso )"
				
				Connection conn = null;
				Statement st = null;
				ResultSet rs = null;
				boolean error = false;
				try{
					conn = getConnection(datasource);
					st = conn.createStatement();
					rs = st.executeQuery(sql);
					List<ProcessSearchIndexes> lpsis = [];
					while(rs.next()){
						ProcessSearchIndexes newpsi = new ProcessSearchIndexes();
						newpsi.setClave(rs.getString("clave"));
						newpsi.setValor(rs.getString("valor"));
						newpsi.setId_caso(rs.getLong("id_caso"));
						newpsi.setId_proceso(rs.getLong("id_proceso"));
						newpsi.setCat_proceso(rs.getString("cat_proceso"));
						lpsis.add(newpsi);
					}
					
					String output = parseProcessSearchIndexes(lpsis, null);
					return buildResponse(responseBuilder, HttpServletResponse.SC_OK, output )
				}catch(SQLException sqle){
					LOGGER.error(sql, sqle);				
				}
				finally{
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException e) { /* ignored */}
					}
					if (st != null) {
						try {
							st.close();
						} catch (SQLException e) { /* ignored */}
					}
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) { /* ignored */}
					}
				}
				LOGGER.error("Estoy en un bloque de codigo que no se deberia ejecutar");
				return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" :" Ha ocurrido un error desconocido, pongase en contacto con el administrador "}""")

			}catch (Exception e){
				e.printStackTrace()
				LOGGER.error(e.getMessage());
			}
		}
			LOGGER.error("Estoy en un bloque de codigo que no se deberia ejecutar");
			return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" :" Ha ocurrido un error desconocido, pongase en contacto con el administrador "}""")
    }
	
	private Connection getConnection(String dsName){
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup(dsName);
		Connection conn = ds.getConnection();
		return conn;
	}

    /**
     * Build an HTTP response.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  httpStatus the status of the response
     * @param  body the response body
     * @return a RestAPIResponse
     */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
     * Returns a paged result like Bonita BPM REST APIs.
     * Build a response with content-range data in the HTTP header.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  body the response body
     * @param  p the page index
     * @param  c the number of result per page
     * @param  total the total number of results
     * @return a RestAPIResponse
     */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }

    /**
     * Load a property file into a java.util.Properties
     */
    Properties loadProperties(String fileName, ResourceProvider resourceProvider) {
        Properties props = new Properties()
        resourceProvider.getResourceAsStream(fileName).withStream { InputStream s ->
            props.load s
        }
        props
    }
	public String getBody(HttpServletRequest request) throws IOException {
		
			String body = null;
			StringBuilder stringBuilder = new StringBuilder();
			BufferedReader bufferedReader = null;
		
			try {
				InputStream inputStream = request.getInputStream();
				if (inputStream != null) {
					bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
					char[] charBuffer = new char[128];
					int bytesRead = -1;
					while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
						stringBuilder.append(charBuffer, 0, bytesRead);
					}
				} else {
					stringBuilder.append("");
				}
			} catch (IOException ex) {
				throw ex;
			} finally {
				if (bufferedReader != null) {
					try {
						bufferedReader.close();
					} catch (IOException ex) {
						throw ex;
					}
				}
			}
		
			body = stringBuilder.toString();
			return body;
		}
	
	public String parseProcessSearchIndexes(List<ProcessSearchIndexes> psis, Long idCaso){
		Map<String, Map<String, String>> output = new HashMap<String, Map<String, String>>();
		Map<String, String> map;
		if(psis.size() == 0){
			return  "No hay ninguna caso con dicho ID";
		}else{
			for(ProcessSearchIndexes psi : psis){	
				
				map = output.get(psi.getId_caso());
				if(map == null){
					map = new HashMap<String, String>();
					map.put("id_caso", psi.getId_caso());
					map.put("id_proceso", psi.getId_proceso());
					map.put("cat_proceso", psi.getCat_proceso());
				}
				map.put(psi.getClave(),psi.getValor());
				output.put(psi.getId_caso(), map);			
			}
			/*
			if(idCaso != null){
				return  new ObjectMapper().writeValueAsString(output.get(idCaso));
			}else{		
				return  new ObjectMapper().writeValueAsString(output.values());
			}
			*/
			return  new ObjectMapper().writeValueAsString(output.values());
		}
		
	}

}
