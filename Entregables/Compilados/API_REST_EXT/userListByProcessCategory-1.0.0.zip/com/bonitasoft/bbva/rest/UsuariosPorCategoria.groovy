package com.bonitasoft.bbva.rest;

import groovy.json.JsonBuilder

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.apache.http.HttpHeaders
import org.bonitasoft.engine.bpm.actor.ActorCriterion;
import org.bonitasoft.engine.bpm.actor.ActorInstance;
import org.bonitasoft.engine.bpm.process.ProcessDeploymentInfo;
import org.bonitasoft.engine.bpm.process.ProcessDeploymentInfoCriterion;
import org.bonitasoft.engine.identity.User;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.bonitasoft.engine.api.APIClient;
import com.bonitasoft.engine.api.IdentityAPI;
import com.bonitasoft.engine.api.ProcessAPI;
import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

class UsuariosPorCategoria implements RestApiController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UsuariosPorCategoria.class)

    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
        // To retrieve query parameters use the request.getParameter(..) method.
        // Be careful, parameter values are always returned as String values

		// Retrieve p parameter
		def p = request.getParameter "p"
		if (p == null) {
			return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "the parameter p is missing"}""")
        }

        // Retrieve c parameter
        def c = request.getParameter "c"
        if (c == null) {
            return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "the parameter c is missing"}""")
		}
		
        // Retrieve categoryId parameter
        def categoryId = request.getParameter "categoryId"
        if (categoryId == null) {
            return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "the parameter categoryId is missing"}""")
        }

		APIClient apiClient = context.getApiClient();
		final ProcessAPI process = apiClient.getProcessAPI();
		final IdentityAPI identity = apiClient.getIdentityAPI();
		
		List<Long> allUsersList = new ArrayList<Long>();
		List<ProcessDeploymentInfo> procesos = process.getProcessDeploymentInfosOfCategory(Long.parseLong(categoryId), Integer.parseInt(p), Integer.parseInt(c), ProcessDeploymentInfoCriterion.VERSION_DESC);
		for(ProcessDeploymentInfo proceso : procesos){
			System.out.println("Proceso-" + proceso.getProcessId() + "-" + proceso.getDisplayName());
			List<ActorInstance> actors = process.getActors(proceso.getProcessId(), Integer.parseInt(p), Integer.parseInt(c), ActorCriterion.NAME_ASC);
			for(ActorInstance a : actors){
				System.out.println(a.getName());
				List<Long> users = process.getUserIdsForActor(proceso.getProcessId(), a.getName(), Integer.parseInt(p), Integer.parseInt(c));
				for(Long u : users){
					System.out.println(u);
					allUsersList.add(u);
				}
			}
			
		}
		HashSet<Long> userList = new HashSet<Long>(allUsersList);
		def results = [];
		
		// Get user information
		for(Long uid : userList){
			User user = identity.getUser(uid);
			def thisUser = ["id": uid, "name": user.getFirstName() + " " + user.getLastName()];
			results << thisUser;
		}

        // Prepare the result
       // def result = [ "categoryId" : categoryId , "myParameterKey" : paramValue ]

        // Send the result as a JSON representation
        // You may use buildPagedResponse if your result is multiple
        return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(results).toPrettyString())
    }

    /**
     * Build an HTTP response.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  httpStatus the status of the response
     * @param  body the response body
     * @return a RestAPIResponse
     */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
     * Returns a paged result like Bonita BPM REST APIs.
     * Build a response with content-range data in the HTTP header.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  body the response body
     * @param  p the page index
     * @param  c the number of result per page
     * @param  total the total number of results
     * @return a RestAPIResponse
     */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }

    /**
     * Load a property file into a java.util.Properties
     */
    Properties loadProperties(String fileName, ResourceProvider resourceProvider) {
        Properties props = new Properties()
        resourceProvider.getResourceAsStream(fileName).withStream { InputStream s ->
            props.load s
        }
        props
    }

}
